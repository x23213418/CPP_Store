from setuptools import setup
setup(name="packagetejas",
      version="0.1",
      description="tejas Package",
      author="tejas",
      packages=['packagetejas'],
      install_requires=['datetime', 'random2'])